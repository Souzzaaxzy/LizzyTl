# 🌱 @souzzaaxzy/baileys


<p align="center">
   Enhanced Baileys v7 with fixes for newsletter media uploads, plus support for interactive messages, albums, and additional message types.
   <br><br>
   <a href="https://github.com/Souzzaaxzy/baileys">
      <img src="https://img.shields.io/npm/v/@souzzaaxzy/baileys?style=for-the-badge&logo=npm"/>
   </a>
   <a href="https://github.com/Souzzaaxzy/baileys">
      <img src="https://img.shields.io/npm/dm/@souzzaaxzy/baileys?style=for-the-badge&logo=npm"/>
   </a>
   <a href="https://github.com/Souzzaaxzy/baileys">
      <img src="https://img.shields.io/github/stars/Souzzaaxzy/baileys?style=for-the-badge&logo=github"/>
   </a>
   <a href="LICENSE">
      <img src="https://img.shields.io/badge/license-MIT-blue?style=for-the-badge"/>
   </a>
   <a href="https://nodejs.org">
      <img src="https://img.shields.io/badge/node-%3E%3D20-339933?logo=node.js&labelColor=green&logoColor=white&style=for-the-badge"/>
   </a>
   <a href="#">
      <img src="https://img.shields.io/badge/ESM-only?logo=javascript&labelColor=yellow&logoColor=black&style=for-the-badge"/>
   </a>
</p>

☕ For donation: [Repositorio](https://github.com/Souzzaaxzy/baileys)

### ✨ Highlights

This fork designed for production use with a focus on clarity and safety:

- 🚫 No obfuscation. Easy to read and audit.
- 🚫 No auto-follow channel (newsletter) behavior.


> [!IMPORTANT]
> Hi everyone,
>
> I want to clarify two separate attribution issues regarding packages derived from this fork.
>
> 1. Direct redistribution of my modifications without attribution
>
> The following packages are operated by the same individual under multiple npm accounts:
>
> - [@nuisockets](https://www.npmjs.com/package/@nuisockets/baileys)
> - [@nuiisatoru](https://www.npmjs.com/package/@nuiisatoru/baileys)
> - [@nuiisweetberry](https://www.npmjs.com/package/@nuiisweetberry/baileys)
> - [@nuiisweety](https://www.npmjs.com/package/@nuiisweety/baileys)
>
> These packages redistribute files and modifications originating from this fork while removing contributor credits and modification notes.
>
> 2. Rebranded republishes of this fork
>
> - [@lumina-md](https://www.npmjs.com/package/@lumina-md/baileys)
> - [@sairidev](https://www.npmjs.com/package/@sairidev/baileys-new)
> - [@lordmega/baileys](https://www.npmjs.com/package/@lordmega/baileys)
> - [phantom-baileys](https://www.npmjs.com/package/phantom-baileys)
> - [nexora-baileys](https://www.npmjs.com/package/nexora-baileys)
>
> These packages primarily repackage or republish this fork under different names while failing to preserve proper attribution, credits, or modification notes.
> 
> To be clear, I am **NOT** the original maintainer of Baileys. Full credit and respect belong to:
>
> https://github.com/WhiskeySockets/Baileys
>
> **Forking is completely acceptable. Removing attribution, contributor credits, or modification history is not.**
>
> Please report if necessary.
>
> Thank you. 🤍

> [!NOTE]
> 📄 This project is maintained with limited scope and is not intended to replace upstream Baileys.
>
> 😞 And, really sorry for my bad english.

### 📋 Table of Contents
- [📋 Table of Contents](#-table-of-contents)
- [✨ Highlights](#-highlights)
- [🛠️ Internal Adjustments](#%EF%B8%8F-internal-adjustments)
- [📨 Messages Handling & Compatibility](#-highlights)
- [🧩 Additional Message Options](#-additional-message-options)
- [📥 Installation](#-installation)
   - [🧩 Import (ESM & CJS)](#-import-esm--cjs)
- [🌐 Connect to WhatsApp (Quick Step)](#-connect-to-whatsapp-quick-step)
   - [🔐 Auth State](#-auth-state)
- [🗄️ Implementing Data Store](#%EF%B8%8F-implementing-data-store)
   - [🧑 Contact names](#-contact-names-sockcontactsgetname)
   - [🎞️ Sticker → GIF/MP4](#%EF%B8%8F-sticker--gifmp4)
- [👥 Join request — quem aprovou/recusou](#-join-request--quem-aprovourecusou)
- [🪪 WhatsApp IDs Explain](#-whatsapp-ids-explain)
- [✉️ Sending Messages](#%EF%B8%8F-sending-messages)
   - [🔠 Text](#-text)
   - [🔔 Mention](#-mention)
   - [😁 Reaction](#-reaction)
   - [📌 Pin Message](#-pin-message)
   - [🔖 Keep Chat](#-keep-chat)
   - [➡️ Forward Message](#%EF%B8%8F-forward-message)
   - [👤 Contact](#-contact)
   - [📍 Location](#-location)
   - [🗓️ Event](#%EF%B8%8F-event)
   - [👥 Group Invite](#-group-invite)
   - [🛍️ Product](#%EF%B8%8F-product)
   - [📊 Poll](#-poll)
   - [💭 Button Response](#-button-response)
   - [✨ Rich Response](#-rich-response)
   - [🧾 Message with Code Block](#-message-with-code-block)
   - [🌏 Message with Inline Entities](#-message-with-inline-entities)
   - [📋 Message with Table](#-message-with-table)
   - [🎞️ Status Mention](#%EF%B8%8F-status-mention)
- [📁 Sending Media Messages](#-sending-media-messages)
   - [🖼️ Image](#%EF%B8%8F-image)
   - [🎥 Video](#-video)
   - [🎞️ GIF](#%EF%B8%8F-gif)
   - [📃 Sticker](#-sticker)
   - [💽 Audio](#-audio)
   - [🗂️ Document](#%EF%B8%8F-document)
   - [🖼️ Album (Image & Video)](#%EF%B8%8F-album-image--video)
   - [📦 Sticker Pack](#-sticker-pack)
- [👉🏻 Sending Interactive Messages](#-sending-interactive-messages)
   - [🔘 Buttons](#-buttons)
   - [📋 List](#-list)
   - [🗄️ Interactive](#%EF%B8%8F-interactive)
   - [🎬 Carousel with Media (Image & Video)](#-carousel-with-media-image--video)
   - [🫙 Hydrated Template](#-hydrated-template)
- [💳 Sending Payment Messages](#-sending-payment-messages)
   - [➕ Invite Payment](#-invite-payment)
   - [🧾 Invoice](#-invoice)
   - [🛍️ Order](#%EF%B8%8F-order)
   - [💳 Request Payment](#-request-payment)
- [👁️ Other Message Options](#%EF%B8%8F-other-message-options)
   - [🤖 AI Icon](#-ai-icon)
   - [🕒 Ephemeral](#-ephemeral)
   - [📰 External Ad Reply](#-external-ad-reply)
   - [🧑‍🧑‍🧒 Group Status](#%E2%80%8D%E2%80%8D-group-status)
   - [📣 Follow Channel Invite](#-follow-channel-invite)
   - [🔁 Reshare (`canBeReshared`)](#-reshare-canbereshared)
   - [👥 Members-only group message](#members-only-group-message)
   - [🔐 Per-message Sender Key rotation](#-per-message-sender-key-rotation-relaygroupmessagewithsenderkeyrotation)
   - [🧪 MarkAsVerifiedAction (experimental)](#-markasverifiedaction-experimental)
   - [🐱 Lottie Sticker](#-lottie-sticker)
   - [🧩 Raw](#-raw)
   - [🏷️ Secure Meta Service Label](#%EF%B8%8F-secure-meta-service-label)
   - [📑 Spoiler](#-spoiler)
   - [👁️ View Once](#%EF%B8%8F-view-once)
   - [👁️ View Once V2](#%EF%B8%8F-view-once-v2)
   - [👁️ View Once V2 Extension](#%EF%B8%8F-view-once-v2-extension)
- [♻️ Modify Messages](#%EF%B8%8F-modify-messages)
   - [🗑️ Delete Messages](#%EF%B8%8F-delete-messages)
   - [✏️ Edit Messages](#%EF%B8%8F-edit-messages)
- [🧰 Additional Contents](#-additional-contents)
   - [🏷️ Find User ID (JID|PN/LID)](#%EF%B8%8F-find-user-id-jidpnlid)
   - [🔑 Request Custom Pairing Code](#-request-custom-pairing-code)
   - [🖼️ Image Processing](#%EF%B8%8F-image-processing)
   - [📣 Newsletter Management](#-newsletter-management)
   - [👥 Group Management](#-group-management)
   - [👥 Community Management](#-community-management)
   - [👤 Profile Management](#-profile-management)
   - [🛒 Business Management](#-business-management)
   - [🔐 Privacy Management](#-privacy-management)
   - [📡 Events](#-events)
- [📞 Voice & Video Calls (VoIP media)](#-voice--video-calls-voip-media)
   - [🔌 Socket session (group calls)](#-socket-session-group-calls)
   - [📱 Standalone client (1:1 calls)](#-standalone-client-11-calls)
   - [🧠 Memory & workers](#-memory--workers)
   - [🐢 "Stuck on connecting"](#-stuck-on-connecting)
   - [🔊 Keeping the call up (and the music playing)](#-keeping-the-call-up-and-the-music-playing)
   - [🎭 The right identity (voice-capable)](#-the-right-identity-voice-capable)
- [🚀 Try the Bot](#-try-the-bot)
- [📦 Fork Base](#-fork-base)
- [📣 Credits](#-credits)

### 🛠️ Internal Adjustments
- 🖼️ Fixed an issue where media could not be sent to newsletters due to an upstream issue.
- 📁 Reintroduced [`makeInMemoryStore`](#%EF%B8%8F-implementing-data-store) with a minimal ESM adaptation and small adjustments for Baileys v7.
- 📦 Switched FFmpeg execution from `exec` to `spawn` for safer process handling.
- 🗃️ Added [`@napi-rs/image`](https://www.npmjs.com/package/@napi-rs/image) as a supported image processing backend in [`getImageProcessingLibrary()`](#%EF%B8%8F-image-processing), offering a balance between performance and compatibility.

### 📨 Messages Handling & Compatibility
- 📩 Expanded messages support for:
   - 🖼️ [Album Message](#%EF%B8%8F-album-image--video)
   - 🎬 [Carousel with Media (Image & Video)](#-carousel-with-media-image--video) **[NEW]**
   - 👤 [Group Status Message](#%E2%80%8D%E2%80%8D-group-status)
   - 🔁 [Reshare (`canBeReshared`)](#-reshare-canbereshared)
   - 👉🏻 [Interactive Message](#-sending-interactive-messages) (buttons, lists, native flows, templates, carousels).
   - 🎞️ [Status Mention Message](#%EF%B8%8F-status-mention)
   - 📦 [Sticker Pack Message](#-sticker-pack)
   - ✨ [Rich Response Message](#-rich-response) **[NEW]**
   - 🧾 [Message with Code Blocks](#-message-with-code-block) **[NEW]**
   - [🌏 Message with Inline Entities](#-message-with-inline-entities) **[NEW]**
   - 📋 [Message with Table](#-message-with-table) **[NEW]**
   - 💳 [Payment-related Message](#-sending-payment-messages) (payment requests, invites, orders, invoices).
- 📰 Simplified sending messages with ad thumbnail using [`externalAdReply`](#-external-ad-reply), without requiring manual `contextInfo`.
- 💭 Added support for quoting messages inside channel (newsletter). **[NEW]**
- 🎀 Added support for [custom button icon](#%EF%B8%8F-interactive). **[NEW]**

### 🧩 Additional Message Options
- 👁️ Added optional boolean flags for message handling:  
   - 🤖 [`ai`](#-ai-icon) - AI icon on message
   - 📣 [`mentionAll`](#-mention) - Mention all group participants without requiring their JIDs in `mentions` or `mentionedJid` **[NEW]**
   - 🔧 [`ephemeral`](#-ephemeral), [`groupStatus`](#%E2%80%8D%E2%80%8D-group-status), [`isLottie`](#-lottie-sticker), [`spoiler`](#-spoiler), [`viewOnce`](#%EF%B8%8F-view-once), [`viewOnceV2`](#%EF%B8%8F-view-once-v2), [`viewOnceV2Extension`](#%EF%B8%8F-view-once-v2-extension), [`interactiveAsTemplate`](#%EF%B8%8F-interactive) - Message wrappers
   - 🔁 [`canBeReshared`](#-reshare-canbereshared) - Marks the message as reshareable (native share/add-to-status on the client) **[NEW]**
   - 🔒 [`secureMetaServiceLabel`](#%EF%B8%8F-secure-meta-service-label) - Secure meta service label on message **[NEW]**
   - 📄 [`raw`](#-raw) - Build your message manually **(DO NOT USE FOR EXPLOITATION)**

### 📥 Installation

- 📄 Via `package.json`

```json
# NPM
"dependencies": {
   "@souzzaaxzy/baileys": "latest"
}

# GitHub
"dependencies": {
   "@souzzaaxzy/baileys": "github:Souzzaaxzy/baileys"
}
```

- ⌨️ Via terminal

```bash
# NPM
npm i @souzzaaxzy/baileys@latest

# GitHub
npm i github:Souzzaaxzy/baileys
```

#### 🧩 Import (ESM & CJS)

```javascript
// --- ESM
import { makeWASocket } from '@souzzaaxzy/baileys'

// --- CJS (tested and working on Node.js 24 ✅)
const { makeWASocket } = require('@souzzaaxzy/baileys')
```

### 🌐 Connect to WhatsApp (Quick Step)

```javascript
import { makeWASocket, delay, DisconnectReason, useMultiFileAuthState } from '@souzzaaxzy/baileys'
import { Boom } from '@hapi/boom'
import pino from 'pino'

// --- Connect with pairing code
const myPhoneNumber = '6288888888888'

const logger = pino({ level: 'silent' })

const connectToWhatsApp = async () => {
   const { state, saveCreds } = await useMultiFileAuthState('session')
    
   const sock = makeWASocket({
      logger,
      auth: state
   })

   sock.ev.on('creds.update', saveCreds)

   sock.ev.on('connection.update', (update) => {
      const { connection, lastDisconnect } = update
      if (connection === 'connecting' && !sock.authState.creds.registered) {
         await delay(1500)
         const code = await sock.requestPairingCode(myPhoneNumber)
         console.log('🔗 Pairing code', ':', code)
      }
      else if (connection === 'close') {
         const shouldReconnect = new Boom(connection?.lastDisconnect?.error)?.output?.statusCode !== DisconnectReason.loggedOut
         console.log('⚠️ Connection closed because', lastDisconnect.error, ', reconnecting ', shouldReconnect)
         if (shouldReconnect) {
            connectToWhatsApp()
         }
      }
      else if (connection === 'open') {
         console.log('✅ Successfully connected to WhatsApp')
      }
   })

   sock.ev.on('messages.upsert', async ({ messages }) => {
      for (const message of messages) {
         if (!message.message) continue

         console.log('🔔 Got new message', ':', message)
         await sock.sendMessage(message.key.remoteJid, {
            text: '👋🏻 Hello world'
         })
      }
   })
}

connectToWhatsApp()
```

#### 🔐 Auth State

> [!NOTE]
> You can use the experimental `useSingleFileAuthState` and `useSqliteAuthState` as an alternative to `useMultiFileAuthState`. However, `useSingleFileAuthState` already includes an internal caching mechanism, so there is no need to wrap `state.keys` with `makeCacheableSignalKeyStore`.

### 🗄️ Implementing Data Store

> [!CAUTION]
> I highly recommend building your own data store, as keeping an entire chat history in memory can lead to excessive RAM usage.

```javascript
import { makeWASocket, makeInMemoryStore, delay, DisconnectReason, useMultiFileAuthState } from '@souzzaaxzy/baileys'
import { Boom } from '@hapi/boom'
import pino from 'pino'

const myPhoneNumber = '6288888888888'

// --- Create your store path
const storePath = './store.json'

const logger = pino({ level: 'silent' })

const connectToWhatsApp = async () => {
   const { state, saveCreds } = await useMultiFileAuthState('session')
    
   const sock = makeWASocket({
      logger,
      auth: state
   })

   const store = makeInMemoryStore({
      logger,
      socket: sock
   })

   store.bind(sock.ev)

   sock.ev.on('creds.update', saveCreds)

   sock.ev.on('connection.update', (update) => {
      const { connection, lastDisconnect } = update
      if (connection === 'connecting' && !sock.authState.creds.registered) {
         await delay(1500)
         const code = await sock.requestPairingCode(myPhoneNumber)
         console.log('🔗 Pairing code', ':', code)
      }
      else if (connection === 'close') {
         const shouldReconnect = new Boom(connection?.lastDisconnect?.error)?.output?.statusCode !== DisconnectReason.loggedOut
         console.log('⚠️ Connection closed because', lastDisconnect.error, ', reconnecting ', shouldReconnect)
         if (shouldReconnect) {
            connectToWhatsApp()
         }
      }
      else if (connection === 'open') {
         console.log('✅ Successfully connected to WhatsApp')
      }
   })

   sock.ev.on('chats.upsert', () => {
      console.log('✉️ Got chats', store.chats.all())
   })

   sock.ev.on('contacts.upsert', () => {
      console.log('👥 Got contacts', Object.values(store.contacts))
   })

   // --- Read store from file
   store.readFromFile(storePath)

   // --- Save store every 3 minutes
   setInterval(() => {
      store.writeToFile(storePath)
   }, 180000)
}

connectToWhatsApp()
```

#### 🧑 Contact names (`sock.contacts.getName`)

The lib emits `contacts.upsert` / `contacts.update` but used to keep nothing, so
there was **no way to ask for a contact's name** — commands that name people
ended up showing the raw number or LID. Now the socket caches contacts and
resolves a display name.

```javascript
// after connecting
sock.contacts.getName('5511999999999@s.whatsapp.net') // 'Fulano de Tal' | undefined
sock.contacts.getName('123456789012345@lid')          // resolves LID ↔ PN aliases
sock.getName('5511999999999')                         // shorthand (also accepts getName(chat, jid))

const c = sock.contacts.getContact(jid) // { id, name, notify, verifiedName, username, lid, phoneNumber }
sock.contacts.getAll()                  // all known contacts
sock.contacts.upsert({ id, name })       // feed it manually if you like
sock.contacts.remove(jid)               // forget one
sock.contacts.clear()                   // forget everything
```

Resolution order: **`name`** (address book) → **`notify`** (observed pushName) →
**`verifiedName`** (business) → **`username`** (`@handle`). Generic values
(`Usuário`, `user`, …), bare phone numbers and raw JIDs are **rejected**, so the
return is `undefined` when there is no trustworthy name — the caller decides the
fallback. A record that carries both `lid` and `phoneNumber` is stored under
**both** aliases, so looking up by either one finds the same name. Partial
updates (e.g. a picture change) do **not** erase the name already known.

Bound options: `max` (default 5000 records) and `ttlMs` (default 7 days). It is
in-memory only — for persistence, feed `sock.contacts.upsert(...)` from your own
store, or use the event emitter directly:

```javascript
import { makeContactStore } from '@souzzaaxzy/baileys'

const contacts = makeContactStore({ ev: sock.ev, max: 10000, ttlMs: 0 })
contacts.getName(jid)
```

#### 🎞️ Sticker → GIF/MP4

Convert an animated sticker (WebP) into a playable GIF or MP4.

> The FFmpeg WebP decoder **skips** the `ANIM`/`ANMF` chunks and yields 0 frames,
> so FFmpeg alone cannot convert an animated sticker. This helper uses **`sharp`**
> (libvips) to read the frames.

```javascript
import { stickerToGif, stickerToMp4, convertSticker, isAnimatedWebP } from '@souzzaaxzy/baileys'

// webpBuffer: the decrypted sticker (downloadContentFromMessage / getFileBuffer)
if (isAnimatedWebP(webpBuffer)) {
   const gif = await stickerToGif(webpBuffer)          // { buffer, mime:'image/gif', ext, pages, fps }
   const mp4 = await stickerToMp4(webpBuffer)          // { buffer, mime:'video/mp4', ... }

   await sock.sendMessage(jid, { video: mp4.buffer, gifPlayback: true })
   await sock.sendMessage(jid, { document: gif.buffer, mimetype: 'image/gif', fileName: 'sticker.gif' })
}

// Or by name:
const out = await convertSticker(webpBuffer, 'mp4')    // 'gif' | 'mp4' | 'video'
```

Options: `fps` (1–50), `width` (resize), `maxFrames` (default 600), `loop` (GIF,
0 = forever), `crf` (MP4, default 23), `timeoutMs` (MP4, default 60s),
`ffmpegPath` (defaults to `process.env.FFMPEG_PATH || 'ffmpeg'`).

Requirements:
- **`sharp`** — mandatory (reads the frames). It is a **peer dependency** and is
  **not** auto-installed by `--legacy-peer-deps`, so add it explicitly:
  `npm i sharp`.
- **FFmpeg** — only for the **MP4** path (the GIF is written by `sharp`, no FFmpeg).

The MP4 is written to a temp file first because the MP4 muxer requires a
**seekable** output (`pipe:1` fails with *"muxer does not support non seekable
output"*); the temp dir is always removed.

### 🪪 WhatsApp IDs Explain

`id` is the WhatsApp ID, called `jid` and `lid` too, of the person or group you're sending the message to.
- It must be in the format `[country code][phone number]@s.whatsapp.net`
   - Example for people: `19999999999@s.whatsapp.net` and `12699999999@lid`.
   - For groups, it must be in the format `123456789-123345@g.us`.
- For Meta AI, it's `11111111111@bot`.
- For broadcast lists, it's `[timestamp of creation]@broadcast`.
- For stories, the ID is `status@broadcast`.

### ✉️ Sending Messages

> [!NOTE]
> You can get the `jid` from `message.key.remoteJid` in the first example.

#### 🔠 Text

```javascript
// --- Send a regular text message
sock.sendMessage(jid, {
   text: '👋🏻 Hello'
}, {
   quoted: message
})

// --- Send a text message with a link preview
const urlA = 'https://github.com/Souzzaaxzy/baileys'

sock.sendMessage(jid, {
   text: urlA + ' 👆🏻 Check it out!',
   linkPreview: {
      'matched-text': urlA,
      title: '🌱 @souzzaaxzy/baileys',
      description: 'Underrated Baileys Fork',
      previewType: 0, // --- Use 1 for video playback in the link preview
      jpegThumbnail: fs.readFileSync('./path/to/image.jpg')
   }
})

// --- Send a text message with a large link preview and favicon
import { prepareWAMessageMedia } from '@souzzaaxzy/baileys'

const urlB = 'https://github.com/Souzzaaxzy/baileys#readme'

const { imageMessage: image } = await prepareWAMessageMedia({
   image: {
      url: './path/to/image.jpg'
   }
}, {
   upload: sock.waUploadToServer,
   mediaTypeOverride: 'thumbnail-link'
})

// --- Set the thumbnail display size
image.height = 720
image.width = 480

sock.sendMessage(jid, {
   text: urlB + ' 👆🏻 Check it out!',
   linkPreview: {
      'matched-text': urlB,
      title: '🌱 @souzzaaxzy/baileys',
      description: 'Underrated Baileys Fork',
      previewType: 0,
      jpegThumbnail: fs.readFileSync('./path/to/image.jpg'),
      highQualityThumbnail: image,
      linkPreviewMetadata: {
         linkMediaDuration: 0, // --- Duration in seconds (for video/audio content)
         socialMediaPostType: 1, // --- Enum: 0 = NONE, 1 = REEL, 2 = LIVE_VIDEO, 3 = LONG_VIDEO, 4 = SINGLE_IMAGE, 5 = CAROUSEL
      } // --- Additional metadata for large link preview
   },
   favicon: {
      url: './path/to/tiny-image.ico'
   }
})
```

#### 🔔 Mention

```javascript
// --- Regular mention
sock.sendMessage(jid, {
   text: '👋🏻 Hello @628123456789',
   mentions: ['628123456789@s.whatsapp.net']
}, {
   quoted: message
})

// --- Mention all
sock.sendMessage(jid, {
   text: '👋🏻 Hello @all',
   mentionAll: true
}, {
   quoted: message
})
```

#### 😁 Reaction

```javascript
sock.sendMessage(jid, {
   react: {
      key: message.key,
      text: '✨'
   }
})
```

#### 📌 Pin Message

```javascript
sock.sendMessage(jid, {
   pin: message.key,
   time: 86400, // --- Set the value in seconds: 86400 (1d), 604800 (7d), or 2592000 (30d)
   type: 1 // --- Or 2 to remove
})
```

#### 🔖 Keep Chat

> [!NOTE]
> Keep Chat can only be used in chats or groups with disappearing messages enabled.

```javascript
sock.sendMessage(jid, {
   keep: message.key,
   type: 1 // --- Or 2 to remove
})
```

#### ➡️ Forward Message

```javascript
sock.sendMessage(jid, {
   forward: message,
   force: true // --- Optional
})
```

#### 👤 Contact

```javascript
const vcard = 'BEGIN:VCARD\n'
            + 'VERSION:3.0\n'
            + 'FN:Lia Wynn\n'
            + 'ORG:Waitress;\n'
            + 'TEL;type=CELL;type=VOICE;waid=628123456789:+62 8123 4567 89\n'
            + 'END:VCARD'

sock.sendMessage(jid, {
   contacts: {
      displayName: 'Lia Wynn',
      contacts: [
         { vcard }
      ]
   }
}, {
   quoted: message
})
```

#### 📍 Location

```javascript
sock.sendMessage(jid, {
   location: {
      degreesLatitude: 24.121231,
      degreesLongitude: 55.1121221,
      name: '👋🏻 I am here'
   }
}, {
   quoted: message
})
```

#### 🗓️ Event

```javascript
sock.sendMessage(jid, {
   event: {
      name: '🎶 Meet & Mingle Party',
      description: 'Meet & Mingle Party is a fun, casual gathering to connect, chat, and build new relationships within the community.',
      call: 'audio', // --- Or "video", this field is optional
      startDate: new Date(Date.now() + 3600000),
      endDate: new Date(Date.now() + 28800000),
      isCancelled: false, // --- Optional
      isScheduleCall: false, // --- Optional
      extraGuestsAllowed: false, // --- Optional
      location: {
         name: 'Jakarta',
         degreesLatitude: -6.2,
         degreesLongitude: 106.8
      }
   }
}, {
   quoted: message
})
```

#### 👥 Group Invite

```javascript
const inviteCode = groupUrl
   .split('chat.whatsapp.com/')[1]
   ?.split('?')[0]

const groupJid = '1201111111111@g.us'
const groupName = '@souzzaaxzy/baileys'

sock.sendMessage(jid, {
   groupInvite: {
      inviteCode,
      inviteExpiration: Date.now() + 86400000,
      text: '👋🏻 Hello, we invite you to join our group.',
      jid: groupJid,
      subject: groupName,
   }
}, {
   quoted: message
})
```

#### 📣 Follow Channel Invite

Send the native **"follow channel"** card
(`newsletterFollowerInviteMessageV2`) — the one WhatsApp shows for a
newsletter/channel with its picture and name.

Before this, the type existed only in the proto: `generateWAMessageContent`
didn't know it and fell into `prepareWAMessageMedia`, which threw
`Invalid media type`. The only way out was the `raw: true` passthrough.

```javascript
await sock.sendMessage(jid, {
   newsletterInvite: {
      jid: '120363410980452460@newsletter',
      name: 'My Channel',
      text: 'Follow our channel for updates!', // optional caption
      thumbnail: jpegBuffer,                    // optional (see below)
   },
   // optional: the "View channel" header on the message itself
   contextInfo: {
      forwardingScore: 999,
      isForwarded: true,
      forwardedNewsletterMessageInfo: {
         newsletterJid: '120363410980452460@newsletter',
         newsletterName: 'My Channel',
      },
   },
}, { quoted: message })
```

**Thumbnail** — pass `thumbnail` with the picture bytes. If you omit it, the
library tries `getProfilePicUrl` (a `MessageGenerationOptions` hook) and
downloads that URL. Failures there are swallowed on purpose: the card is sent
**without** the picture rather than failing.

The `raw: true` form keeps working, for anyone already sending the proto by hand.

#### 🛍️ Product

```javascript
import { randomUUID } from 'crypto'

sock.sendMessage(jid, {
   image: {
      url: './path/to/image.jpg'
   },
   body: '👋🏻 Check my product here!',
   footer: '@souzzaaxzy/baileys',
   product: {
      currencyCode: 'IDR',
      description: '🛍️ Interesting product!',
      priceAmount1000: 70_000_000,
      productId: randomUUID(),
      productImageCount: 1,
      salePriceAmount1000: 65_000_000,
      signedUrl: 'https://github.com/Souzzaaxzy/baileys',
      title: '📦 Starseed (Premium)',
      url: 'https://github.com/Souzzaaxzy/baileys'
   },
   businessOwnerJid: '0@s.whatsapp.net'
})
```

#### 🏬 Catalog Card

The catalog card is the shop entry point: it renders the business picture with a
title and a description, and tapping it opens the catalog. On the wire it is the
`catalog` field of the same `productMessage` used by the product above, so the
caller sends it the same way — `catalogImage` goes through the normal media
upload.

```javascript
sock.sendMessage(jid, {
   catalog: {
      catalogImage: {
         url: './path/to/image.jpg'
      },
      title: '🛍️ My shop',
      description: 'Everything in one place'
   },
   body: '👋🏻 Take a look at my catalog!',
   footer: '@souzzaaxzy/baileys',
   businessOwnerJid: '0@s.whatsapp.net'
})
```

A message may carry `product` and `catalog` at the same time; both end up in the
`productMessage`.

#### 🧾 Multi-Product Message (MPM)

The MPM lists products from the business catalog so the customer can browse.
WhatsApp has no separate `ProductListMessage` type: an MPM is a `listMessage`
with `listType = PRODUCT_LIST` plus a `productListInfo`. The fork builds that for
you from a `productList` input.

```javascript
sock.sendMessage(jid, {
   productList: {
      businessOwnerJid: '0@s.whatsapp.net',
      productSections: [
         {
            title: '🔥 Offers',
            products: [{ productId: 'PROD-1' }, { productId: 'PROD-2' }]
         }
      ],
      // optional header image of the list
      headerImage: { productId: 'PROD-1', jpegThumbnail: bufferImage }
   },
   title: '🛒 Catalog',
   text: 'Choose an item below',
   buttonText: 'Open catalog',
   footer: '@souzzaaxzy/baileys'
})
```

The helpers are exported from the package root, so the payload can also be built
or inspected without a socket:

```javascript
import {
   toProductListInfo,
   parseProductListInfo,
   toBusinessProfileNode,
   toCoverPhotoNode,
   parseBusinessProfileNode
} from '@souzzaaxzy/baileys'
```

#### 📊 Poll

```javascript
// --- Regular poll message
sock.sendMessage(jid, {
   poll: {
      name: '🔥 Voting time',
      values: ['Yes', 'No'],
      selectableCount: 1,
      toAnnouncementGroup: false,
      endDate: new Date(Date.now() + 28800000), // --- Optional
      hideVoter: false, // --- Optional
      canAddOption: false // --- Optional
   }
}, {
   quoted: message
})

// --- Quiz (only for newsletter)
sock.sendMessage('1211111111111@newsletter', {
   poll: {
      name: '🔥 Quiz',
      values: ['Yes', 'No'],
      correctAnswer: 'Yes',
      pollType: 1
   }
}, {
   quoted: message
})

// --- Poll result
sock.sendMessage(jid, {
   pollResult: {
      name: '📝 Poll Result',
      votes: [{
         name: 'Nice',
         voteCount: 10
      }, {
         name: 'Nah',
         voteCount: 2
      }],
      pollType: 0 // Or 1 for quiz
   }
}, {
   quoted: message
})

// --- Poll update
sock.sendMessage(jid, {
   pollUpdate: {
      metadata: {},
      key: message.key,
      vote: {
         enclv: /* <Buffer> */,
         encPayload: /* <Buffer> */
      }
   }
}, {
   quoted: message
})
```

#### 💭 Button Response

```javascript
// --- Using buttonsResponseMessage
sock.sendMessage(jid, {
   type: 'plain',
   buttonReply: {
      id: '#Menu',
      displayText: '✨ Interesting Menu'
   }
}, {
   quoted: message
})

// --- Using interactiveResponseMessage
sock.sendMessage(jid, {
   flowReply: {
      format: 0,
      text: '💭 Response',
      name: 'menu_options',
      paramsJson: JSON.stringify({
         id: '#Menu',
         description: '✨ Interesting Menu'
      })
   }
}, {
   quoted: message
})

// --- Using listResponseMessage
sock.sendMessage(jid, {
   listReply: {
      title: '📄 See More',
      description: '✨ Interesting Menu',
      id: '#Menu'
   }
}, {
   quoted: message
})

// --- Using templateButtonReplyMessage
sock.sendMessage(jid, {
   type: 'template',
   buttonReply: {
      id: '#Menu',
      displayText: '✨ Interesting Menu',
      index: 1
   }
}, {
   quoted: message
})
```

#### ✨ Rich Response

> [!NOTE]
> `richResponse[]` is a representation of [`submessages[]`](https://baileys.wiki/docs/api/namespaces/proto/interfaces/IAIRichResponseSubMessage) inside `richResponseMessage`.

> [!TIP]
> You can still use the original [`submessages[]`](https://baileys.wiki/docs/api/namespaces/proto/interfaces/IAIRichResponseSubMessage) field directly.
> The code example below is just an implementation using a helper, not a required structure.

```javascript
sock.sendMessage(jid, {
   disclaimerText: 'RAW submessages structure example',
   richResponse: [{
      text: 'Example Usage',
   }, {
      language: 'javascript',
      code: [{
         highlightType: 0,
         codeContent: 'console.log("Hello, World!")'
      }]
   }, {
      text: 'Pretty simple, right?\n'
   }, {
      text: 'Comparison between Node.js, Bun, and Deno',
   }, {
      title: 'Runtime Comparison',
      table: [{
         isHeading: true,
         items: ['', 'Node.js', 'Bun', 'Deno']
      }, {
         isHeading: false,
         items: ['Engine', 'V8 (C++)', 'JavaScriptCore (C++)', 'V8 (C++)']
      }, {
         isHeading: false,
         items: ['Performance', '4/5', '5/5', '4/5']
      }]
   }, {
      text: 'Does this help clarify the differences?'
   }]
})
```

> [!TIP]
> You can easily add syntax highlighting by importing `tokenizeCode` directly from Baileys.

```javascript
import { tokenizeCode } from '@souzzaaxzy/baileys'

const language = 'javascript'
const code = 'console.log("Hello, World!")'

sock.sendMessage(jid, {
   disclaimerText: 'Example of tokenizing Code Block',
   richResponse: [{
      text: 'Example Usage',
   }, {
      language,
      code: tokenizeCode(code, language)
   }, {
      text: 'Pretty simple, right?'
   }]
})
```

> 💡 Supported Languages: `css`, `html`, `javascript`, `typescript`, `python`, `golang`, `rust`, `c`, `c#`, `c++`, `bash`, `bat`, `powershell`.

#### 🧾 Message with Code Block

> [!NOTE]
> This feature already includes a built-in tokenizer with `tokenizeCode`.

```javascript
sock.sendMessage(jid, {
   disclaimerText: 'Code Block',
   headerText: '## Example Usage',
   contentText: '---',
   code: 'console.log("Hello, World!")',
   language: 'javascript',
   footerText: 'Pretty simple, right?'
})
```

#### 🌏 Message with Inline Entities

```javascript
sock.sendMessage(jid, {
   disclaimerText: 'Inline Entities',
   headerText: '## Check Out!',
   contentText: '---',
   links: [{
      text: '1. Google',
      title: 'Popular Search Engine',
      url: 'https://www.google.com/'
   }, {
      text: '2. YouTube',
      title: 'Popular Streaming Platform',
      url: 'https://www.youtube.com/'
   }, {
      text: '3. Modded Baileys',
      title: 'Underrated Baileys Fork',
      url: 'https://github.com/Souzzaaxzy/baileys'
   }],
   footerText: '---'
})
```

#### 📋 Message with Table

```javascript
sock.sendMessage(jid, {
   disclaimerText: 'Table',
   headerText: '## Comparison between Node.js, Bun, and Deno',
   contentText: '---',
   title: 'Runtime Comparison',
   table: [
      ['', 'Node.js', 'Bun', 'Deno'],
      ['Engine', 'V8 (C++)', 'JavaScriptCore (C++)', 'V8 (C++)'],
      ['Performance', '4/5', '5/5', '4/5']
   ],
   noHeading: false, // --- Optional
   footerText: 'Does this help clarify the differences?'
})
```

#### 🎞️ Status Mention

```javascript
sock.sendMessage([jidA, jidB, jidC], {
   text: 'Hello! 👋🏻'
})
```

### 📁 Sending Media Messages

> [!NOTE]
> For media messages, you can pass a `Buffer` directly, or an object with either `{ stream: Readable }` or `{ url: string }` (local file path or HTTP/HTTPS URL).

#### 🖼️ Image

```javascript
sock.sendMessage(jid, {
   image: {
      url: './path/to/image.jpg'
   },
   caption: '🔥 Superb'
}, {
   quoted: message
})
```

#### 🎥 Video

```javascript
sock.sendMessage(jid, {
   video: {
      url: './path/to/video.mp4'
   },
   gifPlayback: false, // --- Set true if you want to send video as GIF
   ptv: false,  // --- Set true if you want to send video as PTV
   caption: '🔥 Superb'
}, {
   quoted: message
})
```

#### 🎞️ GIF

Send an animated `.gif` as a WhatsApp GIF. The library converts it to a muted,
looping **MP4 with `gifPlayback: true`** — a raw `.gif` sent as `image`/`video`
does **not** animate in the client, so `gif:` is the one field that does the
right thing for you.

```javascript
sock.sendMessage(jid, {
   gif: {
      url: './path/to/animation.gif'   // Buffer, url, stream or path
   },
   caption: '🔥 Superb'
}, {
   quoted: message
})
```

- Uses `sharp` to read the frames and FFmpeg to encode H.264 (same pipeline as
  `stickerToMp4`); if either is missing it falls back to sending the GIF as a
  still image.
- Works as the **header of an interactive card** (`gif:` + `caption` + `nativeFlow`),
  which is the shape a media card with buttons needs.
- To convert a GIF yourself, use `gifToMp4(buffer)` (exported alongside
  `stickerToMp4`).

#### 📃 Sticker

```javascript
sock.sendMessage(jid, {
   sticker: {
      url: './path/to/sticker.webp'
   }
}, {
   quoted: message
})
```

#### 💽 Audio

```javascript
sock.sendMessage(jid, {
   audio: {
      url: './path/to/audio.mp3'
   },
   ptt: false // --- Set true if you want to send audio as Voice Note
}, {
   quoted: message
})
```

#### 🗂️ Document

```javascript
sock.sendMessage(jid, {
   document: {
      url: './path/to/document.pdf'
   },
   mimetype: 'application/pdf',
   caption: '✨ My work!'
}, {
   quoted: message
})
```

#### 🖼️ Album (Image & Video)

```javascript
sock.sendMessage(jid, {
   album: [{
      image: {
         url: './path/to/image.jpg'
      },
      caption: '1st image'
   }, {
      video: {
         url: './path/to/video.mp4'
      },
      caption: '1st video'
   }, {
      image: {
         url: './path/to/image.jpg'
      },
      caption: '2nd image'
   }, {
      video: {
         url: './path/to/video.mp4'
      },
      caption: '2nd video'
   }]
}, {
   quoted: message
})
```

#### 📦 Sticker Pack

> [!IMPORTANT]
> If `sharp` or `@napi-rs/image` is not installed, the `cover` and `stickers` must already be in WebP format.

```javascript
sock.sendMessage(jid, {
   cover: {
      url: './path/to/image.webp'
   },
   stickers: [{
      data: {
         url: './path/to/image.webp'
      }
   }, {
      data: {
         url: './path/to/image.webp'
      }
   }, {
      data: {
         url: './path/to/image.webp'
      }
   }],
   name: '📦 My Sticker Pack',
   publisher: '🌟 Lia Wynn',
   description: '@souzzaaxzy/baileys'
}, {
   quoted: message
})
```

### 👉🏻 Sending Interactive Messages

#### 🔘 Buttons

```javascript
// --- Regular buttons message
sock.sendMessage(jid, {
   text: '👆🏻 Buttons!',
   footer: '@souzzaaxzy/baileys',
   buttons: [{
      text: '👋🏻 SignUp',
      id: '#SignUp'
   }]
}, {
   quoted: message
})

// --- Buttons with Media & Native Flow
sock.sendMessage(jid, {
   image: {
      url: './path/to/image.jpg'
   },
   caption: '👆🏻 Buttons and Native Flow!',
   footer: '@souzzaaxzy/baileys',
   buttons: [{
      text: '👋🏻 Rating',
      id: '#Rating'
   }, {
      text: '📋 Select',
      sections: [{
         title: '✨ Section 1',
         rows: [{
            header: '',
            title: '💭 Secret Ingredient',
            description: '',
            id: '#SecretIngredient'
         }]
      }, {
         title: '✨ Section 2',
         highlight_label: '🔥 Popular',
         rows: [{
            header: '',
            title: '🏷️ Coupon',
            description: '',
            id: '#CouponCode'
         }]
      }]
   }]
}, {
   quoted: message
})
```

#### 📋 List

> [!NOTE]
> It only works in private chat (`@s.whatsapp.net`).

```javascript
sock.sendMessage(jid, {
   text: '📋 List!',
   footer: '@souzzaaxzy/baileys',
   buttonText: '📋 Select',
   title: '👋🏻 Hello',
   sections: [{
      title: '🚀 Menu 1',
      rows: [{
         title: '✨ AI',
         description: '',
         rowId: '#AI'
      }]
   }, {
      title: '🌱 Menu 2',
      rows: [{
         title: '🔍 Search',
         description: '',
         rowId: '#Search'
      }]
   }]
}, {
   quoted: message
})
```

#### 🗄️ Interactive

```javascript
// --- Native Flow
sock.sendMessage(jid, {
   image: {
      url: './path/to/image.jpg'
   },
   caption: '🗄️️ Interactive!',
   footer: '@souzzaaxzy/baileys',
   optionText: '👉🏻 Select Options', // --- Optional, wrap all native flow into a single list
   optionTitle: '📄 Select Options', // --- Optional
   offerText: '🏷️ Newest Coupon!', // --- Optional, add an offer into message
   offerCode: '@souzzaaxzy/baileys', // --- Optional
   offerUrl: 'https://github.com/Souzzaaxzy/baileys', // --- Optional
   offerExpiration: Date.now() + 3_600_000, // --- Optional
   nativeFlow: [{
      text: '👋🏻 Greeting',
      id: '#Greeting',
      icon: 'review' // --- Optional
   }, {
      text: '📞 Call',
      call: '628123456789'
   }, {
      text: '📋 Copy',
      copy: '@souzzaaxzy/baileys'
   }, {
      text: '🌐 Source',
      url: 'https://github.com/Souzzaaxzy/baileys',
      useWebview: true // --- Optional
   }, {
      text: '📋 Select',
      sections: [{
         title: '✨ Section 1',
         rows: [{
            header: '',
            title: '🏷️ Coupon',
            description: '',
            id: '#CouponCode'
         }]
      }, {
         title: '✨ Section 2',
         highlight_label: '🔥 Popular',
         rows: [{
            header: '',
            title: '💭 Secret Ingredient',
            description: '',
            id: '#SecretIngredient'
         }]
      }],
      icon: 'default' // --- Optional
   }],
   interactiveAsTemplate: false, // --- Optional, wrap the interactive message into a template
}, {
   quoted: message
})

// --- Carousel & Native Flow
sock.sendMessage(jid, {
   text: '🗂️ Interactive with Carousel!',
   footer: '@souzzaaxzy/baileys',
   cards: [{
      image: {
         url: './path/to/image.jpg'
      },
      caption: '🖼️ Image 1',
      footer: '🏷️️ Pinterest',
      nativeFlow: [{
         text: '🌐 Source',
         url: 'https://github.com/Souzzaaxzy/baileys',
         useWebview: true
      }]
   }, {
      image: {
         url: './path/to/image.jpg'
      },
      caption: '🖼️ Image 2',
      footer: '🏷️ Pinterest',
      offerText: '🏷️ New Coupon!',
      offerCode: '@souzzaaxzy/baileys',
      offerUrl: 'https://github.com/Souzzaaxzy/baileys',
      offerExpiration: Date.now() + 3_600_000,
      nativeFlow: [{
         text: '🌐 Source',
         url: 'https://github.com/Souzzaaxzy/baileys'
      }]
   }, {
      image: {
         url: './path/to/image.jpg'
      },
      caption: '🖼️ Image 3',
      footer: '🏷️ Pinterest',
      optionText: '👉🏻 Select Options',
      optionTitle: '👉🏻 Select Options',
      offerText: '🏷️ New Coupon!',
      offerCode: '@souzzaaxzy/baileys',
      offerUrl: 'https://github.com/Souzzaaxzy/baileys',
      offerExpiration: Date.now() + 3_600_000,
      nativeFlow: [{
         text: '🛒 Product',
         id: '#Product',
         icon: 'default'
      }, {
         text: '🌐 Source',
         url: 'https://github.com/Souzzaaxzy/baileys'
      }]
   }]
}, {
   quoted: message
})

// --- Native Flow with Audio in the Footer
sock.sendMessage(jid, {
   text: '🔈 Music in the footer!',
   audioFooter: {
      url: './path/to/audio.mp3'
   }, // --- Like other media upload methods, buffers and streams are supported
   nativeFlow: [{
      text: '👍🏻 Good, next',
      id: '#Next',
      icon: 'review'
   }, {
      text: '👎🏻 Skip',
      id: '#Skip',
      icon: 'default'
   }]
}, {
   quoted: message
})
```

#### 🎬 Carousel with Media (Image & Video)

A carousel card header accepts **image**, **video** and **product**. Images and
videos go through the regular media pipeline (upload, encryption, thumbnail), so
buffers and streams work exactly like in the other media methods.

Video card:

```javascript
sock.sendMessage(jid, {
   text: '🎬 Carousel with video!',
   footer: '@souzzaaxzy/baileys',
   cards: [{
      video: {
         url: './path/to/video.mp4'
      },
      caption: '🎬 Video 1'
   }, {
      video: {
         url: './path/to/video.mp4'
      },
      caption: '🎬 Video 2',
      nativeFlow: [{
         text: '🌐 Source',
         url: 'https://github.com/Souzzaaxzy/baileys'
      }]
   }]
}, {
   quoted: message
})
```

Mixed image + video carousel (each card keeps its own media, in order):

```javascript
sock.sendMessage(jid, {
   text: '🗂️ Mixed carousel!',
   cards: [{
      image: {
         url: './path/to/image.jpg'
      },
      caption: '🖼️ Image'
   }, {
      video: {
         url: './path/to/video.mp4'
      },
      caption: '🎬 Video'
   }, {
      image: {
         url: './path/to/image.jpg'
      },
      caption: '🖼️ Image 2'
   }]
}, {
   quoted: message
})
```

Per-card options that also apply to video:

- `gifPlayback: true` — sends the video as a GIF (muted, looping);
- `ptv: true` — sends the video as a video note; it is normalised into the
  card's `videoMessage` header;
- `seconds` — duration, when it should not be computed with FFmpeg;
- `thumbnail` — a custom `jpegThumbnail` for the card;
- `title` / `subtitle` — shown next to the media.

> [!NOTE]
> `caption` and `text` are interchangeable for the card body. A card with media
> but **no** `caption`/`text` is valid: the media is still attached to the card.
> A card without `nativeFlow` is also valid — it simply has no buttons.

A card can also be **text-only** (a `text` field with no media — a real text
card, not an image) and can carry an **audio player** in the footer
(`audioFooter`). Both build on the same carousel:

```javascript
sock.sendMessage(jid, {
   text: '🗂️ Text + audio cards!',
   cards: [{
      text: 'Card with only text'
   }, {
      text: 'Card with an audio player',
      audioFooter: {
         url: './path/to/audio.mp3'
      }
   }]
}, {
   quoted: message
})
```

The optional `carouselCardType` on the message selects the layout
(`CarouselCardType.UNKNOWN` by default, `HSCROLL_CARDS`, `ALBUM_IMAGE`).

#### 🫙 Hydrated Template

```javascript
sock.sendMessage(jid, {
   title: '👋🏻 Hello',
   image: {
      url: './path/to/image.jpg'
   },
   caption: '🫙 Template!',
   footer: '@souzzaaxzy/baileys',
   templateButtons: [{
      text: '👉?? Tap Here',
      id: '#Order'
   }, {
      text: '🌐 Source',
      url: 'https://github.com/Souzzaaxzy/baileys'
   }, {
      text: '📞 Call',
      call: '628123456789'
   }]
}, {
   quoted: message
})
```

### 💳 Sending Payment Messages

#### ➕ Invite Payment

```javascript
sock.sendMessage(jid, {
   paymentInviteServiceType: 3 // 1, 2, or 3
})
```

#### 🧾 Invoice

> [!NOTE]
> Invoice message are not supported yet.

```javascript
sock.sendMessage(jid, {
   image: {
      url: './path/to/image.jpg'
   },
   invoiceNote: '🏷️ Invoice'
})
```

#### 🛍️ Order

```javascript
sock.sendMessage(chat, {
   orderText: '🛍️ Order',
   thumbnail: fs.readFileSync('./path/to/image.jpg') // --- Must in buffer format
}, {
   quoted: message
})
```

#### 💳 Request Payment

```javascript
sock.sendMessage(jid, {
   text: '💳 Request Payment',
   requestPaymentFrom: '0@s.whatsapp.net'
})
```

### 👁️ Other Message Options

#### 🤖 AI Icon

> [!NOTE]
> It only works in private chat (`@s.whatsapp.net`).

```javascript
sock.sendMessage(jid, {
   image: {
      url: './path/to/image.jpg'
   },
   caption: '🤖 With AI icon!',
   ai: true
}, {
   quoted: message
})
```

#### 🕒 Ephemeral

> [!NOTE]
> Wrap message into `ephemeralMessage`

```javascript
sock.sendMessage(jid, {
   image: {
      url: './path/to/image.jpg'
   },
   caption: '👁️ Ephemeral',
   ephemeral: true
})
```

#### 📰 External Ad Reply

> [!NOTE]
> Add an ad thumbnail to messages (may not be displayed on some WhatsApp versions).

```javascript
sock.sendMessage(jid, {
   text: '📰 External Ad Reply',
   externalAdReply: {
      title: '📝 Did you know?',
      body: '❓ I dont know',
      thumbnail: fs.readFileSync('./path/to/image.jpg'), // --- Must in buffer format
      largeThumbnail: false, // --- Or true for bigger thumbnail
      url: 'https://github.com/Souzzaaxzy/baileys' // --- Optional, used for WhatsApp internal thumbnail caching and direct URL
   }
}, {
   quoted: message
})
```

#### 🧑‍🧑‍🧒 Group Status

> [!NOTE]
> Publishes a native **group status** inside the group itself. It only works in
> group chat (`@g.us`) -- the content goes to the group JID, never to
> `status@broadcast`, so it is neither a personal status nor a regular message.

Internally this flag does three things at once:

1. sets `contextInfo.isGroupStatus = true`;
2. wraps the content into `groupStatusMessageV2`;
3. adds the `is_group_status='true'` attribute to the stanza.

Text status:

```javascript
sock.sendMessage(jid, {
   text: '👥 Group Status!',
   groupStatus: true
})
```

Image status:

```javascript
sock.sendMessage(jid, {
   image: {
      url: './path/to/image.jpg'
   },
   caption: '👥 Group Status!',
   groupStatus: true
})
```

Video status:

```javascript
sock.sendMessage(jid, {
   video: {
      url: './path/to/video.mp4'
   },
   caption: '👥 Group Status!',
   groupStatus: true
})
```

Audio status:

```javascript
sock.sendMessage(jid, {
   audio: {
      url: './path/to/audio.mp3'
   },
   mimetype: 'audio/mp4',
   ptt: false, // --- Set true to send it as Voice Note
   groupStatus: true
})
```

Combining with other options -- e.g. a reshareable status (see
[Reshare](#-reshare-canbereshared)):

```javascript
sock.sendMessage(jid, {
   text: '📢 Group Status!',
   groupStatus: true,
   canBeReshared: true
})
```

#### 🔁 Reshare (`canBeReshared`)

> [!NOTE]
> Marks the message as reshareable, so recipients get the native **reshare /
> add-to-status** action on the client. Use it together with `groupStatus` (or
> any other wrapper) when the content should be shareable.

The shorthand -- just pass the flag along with `groupStatus`:

```javascript
sock.sendMessage(jid, {
   text: '📢 Group Status!',
   groupStatus: true,
   canBeReshared: true   // --- sets contextInfo.featureEligibilities.canBeReshared
})
```

The flag is a shorthand for the permission only: it sets
`contextInfo.featureEligibilities.canBeReshared` and touches nothing else.

To also send the rest of the status metadata that the official client includes
(and to keep full control over it), pass the whole `contextInfo` yourself. These
are plain WhatsApp protobuf fields -- nothing this fork invented, so the same
payload can be built with any other library:

```javascript
sock.sendMessage(jid, {
   text: '📢 Group Status!',
   groupStatus: true,
   contextInfo: {
      featureEligibilities: {
         canBeReshared: true,
         canReceiveMultiReact: true
      },
      statusSourceType: 4,                          // --- TEXT
      statusAttributions: [{ type: 10 }],           // --- STATUS_CLOSE_SHARING
      statusAudienceMetadata: { audienceType: 1 }   // --- CLOSE_FRIENDS
   }
})
```

Both give you a reshareable group status (content wrapped into
`groupStatusMessageV2`, with `isGroupStatus` in `contextInfo`); the second one
just carries more status metadata. The shorthand and a manual `contextInfo` can
even be combined -- the flag merges into whatever `contextInfo` is already there
without overwriting it.

> [!IMPORTANT]
> The client reads this permission from the **message payload**. Without it,
> statuses posted by a library do not show the reshare button even when
> "Allow Sharing" is enabled in the account's status privacy settings.
> The button itself belongs to the official WhatsApp client -- this flag only
> declares the permission.
>
> Known limitation (WhatsApp platform side, not this library): audio statuses
> (`ptt: true`) do not offer reshare regardless of this flag.


#### 👥 Members-only group message

> [!WARNING]
> **Read the limitations before using this.** The stanza is accepted by the
> server, and a restricted recipient genuinely cannot decrypt the message — but
> the recipient can still tell that a message exists in the group. This is not a
> way to say something to part of a group without them knowing something was
> said. See the limitations below.

Narrows the Sender Key fan-out of a group message to a subset of the group, so
the Sender Key material reaches only those devices. Everyone else is not
addressed at all.

```javascript
// Only the non-admin participants can read this.
sock.sendMessage(groupJid, { text: 'Members only 👋' }, {
   recipientMode: 'members-only'
})

// The inverse, and an explicit list, are also supported.
sock.sendMessage(groupJid, { text: 'Admins only' }, { recipientMode: 'admins-only' })
sock.sendMessage(groupJid, { text: 'Just you two' }, {
   recipientParticipants: ['5511...@lid', '5511...@s.whatsapp.net']
})
```

`recipientMode` accepts `'all'` (the default behaviour), `'admins-only'` and
`'members-only'`. Admin roles come from the group metadata (`admin` is `'admin'`
for a promoted admin and `'superadmin'` for the creator) — there is no name,
number or position heuristic. `recipientParticipants` takes precedence over
`recipientMode` when both are given.

**How it works.** A group message is one Sender Key ciphertext (`<enc
type="skmsg">`) plus a per-device `<to>` node carrying the Sender Key
distribution message. The send path already derives its device list from the
group participants, so restricting the participant list restricts the fan-out:
`resolveGroupRecipients` (see `lib/Utils/recipient-selector.js`) filters the list
before device discovery, and everything downstream follows. The `phash` is
computed from that same (now partial) device list, which keeps it consistent
with what was actually addressed.

When a restriction is active the `<enc>` nodes are also marked
`decrypt-fail="hide"`, so clients of the excluded participants hide the entry
instead of showing a "waiting for this message" placeholder.

**Limitations**

- **It only excludes participants who never received the Sender Key.** This is
  the important one, and it was measured, not assumed. The Sender Key is
  **reused** across sends: `GroupSessionBuilder.create()` only generates a key
  when the record is empty, and `GroupCipher.encrypt()` continues the **same**
  chain. So a participant who received the Sender Key from any earlier normal
  message still holds it, and can decrypt a later restricted message with it —
  the restriction only stops the *new* distribution, not the decryption. An
  excluded participant genuinely cannot decrypt **only** if it never received
  the key (a member added after the last normal send, or a group where the very
  first message was already restricted). See
  `tests/members-only-leak.test.js`, which decrypts a restricted message as an
  excluded admin and asserts that it succeeds.
- **The server still knows the message exists.** The stanza is addressed to the
  group, so excluded participants receive the message reference and may see a
  notification/preview for it. They cannot read the content, but they are not
  unaware.
- **Individuals, not roles.** The subset is resolved from the participant list at
  send time. Someone promoted to admin afterwards is not retroactively excluded
  from messages already sent, and a new member does not receive old ones. Each
  send resolves the group metadata fresh.
- **Group settings still apply.** Announcement-only groups etc. are enforced by
  the server, independently of this option.
- **Only group messages.** On a 1:1 chat there is no Sender Key; the option is
  ignored there.
- **Not a confidentiality boundary against WhatsApp.** This narrows the
  client-side fan-out; it says nothing about what the server can observe.

This was verified end to end in `tests/members-only-send.test.js`: the real send
path runs against a recorded transport, pairwise sessions are built with real
key material, and the test decrypts what each device received with its own
private keys — proving an included member gets the Sender Key and can read the
message, while an excluded participant has no `<to>` node at all. It has **not**
been validated on a real device against the live WhatsApp servers; treat the
client-side rendering of the excluded entry as unverified until someone does.

`tests/members-only-leak.test.js` covers the reuse problem: it sends a normal
message (both an admin and a member receive the Sender Key), then a restricted
message, and shows the excluded admin decrypting the restricted ciphertext with
the key it already had. The same file also shows that rotating the Sender Key
(clearing both `sender-key` and `sender-key-memory`) before the restricted send
**does** block that admin — so rotation, not recipient filtering, is what would
be needed for the stronger guarantee.

#### 🔐 Per-message Sender Key rotation (`relayGroupMessageWithSenderKeyRotation`)

This is the stronger guarantee the note above points at, exposed as one call:

```javascript
await sock.relayGroupMessageWithSenderKeyRotation(groupJid, content.message, {
   allowedParticipants: ['5511...@lid', '5512...@lid'], // members only
   messageId: generatedId
})
```

What it does, in order, for **each** protected message:

1. **rotates** the group Sender Key — appends a NEW state (new id, chain key and
   signing key pair) without destroying the previous one, so older messages stay
   decryptable;
2. **restricts the fan-out** to `allowedParticipants` *before* device discovery,
   so the SKDM, the `<to>` nodes, the `phash` and the ciphertext all follow the
   subset;
3. encrypts the message with the **new** state and attaches the matching SKDM;
4. marks the `<enc>` `decrypt-fail="hide"`;
5. **registers the messageId for retry suppression**;
6. **rolls back** the temporary state.

Points worth knowing before using it:

- **The rollback runs in a `finally`.** It happens on success, on error, on an
  exception thrown by encryption or distribution, on a timeout and on a
  transport failure. If it did not, the temporary key would stay active and the
  group would keep encrypting with a key only the authorized subset ever
  received — the group would go unreadable for everyone else.
- **Exactly one rollback per failure.** There are two rollback paths (the inner
  `finally` and the wrapper's `catch`); the wrapper only runs when the inner one
  did not, which the tests assert by counting calls.
- **Retry is withheld per message.** An excluded participant that asks for a
  resend gets nothing, because answering would re-send the content **pairwise**
  to exactly the device the rotation left without the key. Suppression is keyed
  by `messageId`, so retries of ordinary messages are untouched.
- **Fails closed.** An invalid JID, an empty participant list or a restriction
  that matches nobody throws — it never falls back to sending to the whole
  group.
- **`decrypt-fail="hide"` is not the protection.** It only tells the client not
  to render a placeholder. The protection is that an unauthorized device never
  receives the key material.
- **Concurrency.** Rotations for the same group are serialized, so their windows
  (rotate → encrypt → distribute → rollback) cannot overlap — an overlap would
  make both `pop()` calls remove the wrong state. Rotations of different groups
  still run in parallel.

Measurements from `tests/sender-key-rotation-burst.test.js` (real Signal
sessions, real decryption, local loopback transport — so these bound the
rotation cost, not the network):

| burst | stanzas | unique sender key ids | admin decrypts | burst time | avg/message |
|---|---|---|---|---|---|
| 1 | 1 | 1 | 0 | 16.8 ms | 16.8 ms |
| 5 | 5 | 5 | 0 | 44.1 ms | 8.8 ms |
| 10 | 10 | 10 | 0 | 96.3 ms | 9.6 ms |
| 25 | 25 | 25 | 0 | 280.4 ms | 11.2 ms |
| 50 | 50 | 50 | 0 | 514.1 ms | 10.3 ms |

Each protected message carries its **own** SKDM and its **own** sender key id,
and a fresh device fed only that message's SKDM decrypts it — so no protected
message depends on another's temporary key.

#### 🧪 MarkAsVerifiedAction (experimental)

> [!IMPORTANT]
> This is **experimental and observational**. Nothing here claims that any
> account gains a verified badge. The name of the action is not evidence.

The structure exists in the schema (verified against WhatsApp Web's own internal
spec, `Message$MarkAsVerifiedAction`):

```proto
message MarkAsVerifiedAction {
  optional string userJidString       = 1;  // STRING
  optional bool   verified            = 2;  // BOOL
  optional bytes  verifiedIdentityKey = 3;  // BYTES
  optional uint64 actionSeq           = 4;  // UINT64
}
```

Its parent is `Message.ProtocolMessage`, field **32**, with
`ProtocolMessage.Type.MARK_AS_VERIFIED_ACTION = 36`:

```proto
optional MarkAsVerifiedAction markAsVerifiedAction = 32;
```

**It is not App State.** There is no `markAsVerified*` in `SyncActionValue`, so
there is no `SyncdPatch` / `SyncdMutation` / `SyncdValue` / LTHash path for it.
Building one would invent a transport the schema does not describe.

Sending (through the existing relay — no second transport):

```javascript
await sock.sendMarkAsVerifiedAction({
   userJidString: '5511999999999@s.whatsapp.net', // PN or LID; not converted
   verified: true                                  // omit to leave it ABSENT
   // verifiedIdentityKey: ...                     // never fabricated
   // actionSeq: ...                               // never guessed
})
```

Receiving (observational):

```javascript
sock.ev.on('chats.update', updates => {
   for (const u of updates) {
      if (u.markAsVerifiedAction) { /* what actually arrived */ }
   }
})
```

Honest scope:

- **The direction is not established.** No client code that *originates* this
  action was found — WhatsApp Web's bundle only defines the schema. Sending is
  an experiment: the server may ignore or reject it.
- **`verified` absent ≠ `verified: false`.** Omitted fields stay absent on the
  wire; the helpers preserve that distinction.
- **`verifiedIdentityKey` is never fabricated.** No random bytes, no other
  account's key. If there is no legitimate value, the field is simply omitted.
- **The identity key is never logged.** Diagnostics report its byte *length*
  only.
- **Fails closed.** An invalid JID or payload throws; nothing is sent.

#### 🐱 Lottie Sticker

> [!NOTE]
> Wrap message into `lottieStickerMessage`

```javascript
sock.sendMessage(jid, {
   sticker: {
      url: './path/to/sticker.webp'
   },
   isLottie: true
})
```

#### 🧩 Raw

```javascript
sock.sendMessage(jid, {
   extendedTextMessage: {
      text: '📃 Built manually from scratch using the raw WhatsApp proto structure',
      contextInfo: {
         externalAdReply: {
            title: '@souzzaaxzy/baileys',
            thumbnail: fs.readFileSync('./path/to/image.jpg'),
            sourceApp: 'whatsapp',
            showAdAttribution: true,
            mediaType: 1
         }
      }
   },
   raw: true
}, {
   quoted: message
})
```

#### 🏷️ Secure Meta Service Label

```javascript
sock.sendMessage(jid, {
   text: '🏷️ Just a label!',
   secureMetaServiceLabel: true
})
```

#### 📑 Spoiler

> [!NOTE]
> Wrap message into `spoilerMessage`

```javascript
sock.sendMessage(jid, {
   image: {
      url: './path/to/image.jpg'
   },
   caption: '❔ Spoiler',
   spoiler: true
})
```

#### 👁️ View Once

> [!NOTE]
> Wrap message into `viewOnceMessage`

```javascript
sock.sendMessage(jid, {
   image: {
      url: './path/to/image.jpg'
   },
   caption: '👁️ View Once',
   viewOnce: true
})
```

#### 👁️ View Once V2

> [!NOTE]
> Wrap message into `viewOnceMessageV2`

```javascript
sock.sendMessage(jid, {
   image: {
      url: './path/to/image.jpg'
   },
   caption: '👁️ View Once V2',
   viewOnceV2: true
})
```

#### 👁️ View Once V2 Extension

> [!NOTE]
> Wrap message into `viewOnceMessageV2Extension`

```javascript
sock.sendMessage(jid, {
   image: {
      url: './path/to/image.jpg'
   },
   caption: '👁️ View Once V2 Extension',
   viewOnceV2Extension: true
})
```

### ♻️ Modify Messages

#### 🗑️ Delete Messages

```javascript
sock.sendMessage(jid, {
   delete: message.key
})
```

#### ✏️ Edit Messages

```javascript
// --- Edit plain text
sock.sendMessage(jid, {
   text: '✨ I mean, nice!',
   edit: message.key
})

// --- Edit media messages caption
sock.sendMessage(jid, {
   caption: '✨ I mean, here is the image!',
   edit: message.key
})
```

### 🧰 Additional Contents

#### 🏷️ Find User ID (JID|PN/LID)

> [!NOTE]
> The ID must contain numbers only (no +, (), or -) and must include the country code with WhatsApp ID format.

```javascript
// --- PN (Phone Number)
const phoneNumber = '6281111111111@s.whatsapp.net'

const ids = await sock.findUserId(phoneNumber)

console.log('🏷️ Got user ID', ':', ids)

// --- LID (Local Identifier)
const lid = '43411111111111@lid'

const ids = await sock.findUserId(lid)

console.log('🏷️ Got user ID', ':', ids)

// --- Output
// {
//    phoneNumber: '6281111111111@s.whatsapp.net',
//    lid: '43411111111111@lid'
// }
// --- Output when failed
// {
//    phoneNumber: '6281111111111@s.whatsapp.net',
//    lid: undefined
// }
// --- Same output shape regardless of input type
```

#### 🔑 Request Custom Pairing Code

> [!NOTE]
> The phone number must contain numbers only (no +, (), or -) and must include the country code.

```javascript
const phoneNumber = '6281111111111'
const customPairingCode = 'STARFALL'

await sock.requestPairingCode(phoneNumber, customPairingCode)

console.log('🔗 Pairing code', ':', customPairingCode)
```

#### 🖼️ Image Processing

> [!NOTE]
> Automatically use available image processing library: `sharp`, `@napi-rs/image`, or `jimp`

```javascript
import { getImageProcessingLibrary } from '@souzzaaxzy/baileys'
import { readFile } from 'fs/promises'

const lib = await getImageProcessingLibrary()

const bufferOrFilePath = './path/to/image.jpg'
const width = 512

let output

// --- If sharp installed
if (lib.sharp?.default) {
   const img = lib.sharp.default(bufferOrFilePath)

   output = await img.resize(width)
      .jpeg({ quality: 80 })
      .toBuffer()
}

// --- If @napi-rs/image installed
else if (lib.image?.Transformer) {
   // --- Must in buffer format
   const inputBuffer = Buffer.isBuffer(bufferOrFilePath)
      ? bufferOrFilePath
      : await readFile(bufferOrFilePath)

   const img = new lib.image.Transformer(inputBuffer)

   output = await img.resize(width, undefined, 0)
      .jpeg(50)
}

// --- If jimp installed
else if (lib.jimp?.Jimp) {
   const img = await lib.jimp.Jimp.read(bufferOrFilePath)

   output = await img
      .resize({ w: width, mode: lib.jimp.ResizeStrategy.BILINEAR })
      .getBuffer('image/jpeg', { quality: 50 })
}

// --- Fallback
else {
   throw new Error('No image processing available')
}

console.log('✅ Process completed!')
console.dir(output, { depth: null })
```

#### 📣 Newsletter Management

```javascript
// --- Create a new one
sock.newsletterCreate('@souzzaaxzy/baileys', '📣 Fresh updates weekly')

// --- Get info
const metadata = sock.newsletterMetadata('1231111111111@newsletter')
console.dir(metadata, { depth: null })

// --- Get subscribers count
const subscribers = await sock.newsletterSubscribers('1231111111111@newsletter')
console.dir(subscribers, { depth: null })

// --- Follow and Unfollow
sock.newsletterFollow('1231111111111@newsletter')
sock.newsletterUnfollow('1231111111111@newsletter')

// --- Mute and Unmute
sock.newsletterMute('1231111111111@newsletter')
sock.newsletterUnmute('1231111111111@newsletter')

// --- Demote admin
sock.newsletterDemote('1231111111111@newsletter', '6281111111111@s.whatsapp.net')

// --- Change owner
sock.newsletterChangeOwner('1231111111111@newsletter', '6281111111111@s.whatsapp.net')

// --- Update newsletter
sock.newsletterUpdate('1231111111111@newsletter', { name: '@souzzaaxzy/baileys' })

// --- Change name
sock.newsletterUpdateName('1231111111111@newsletter', '📦 @souzzaaxzy/baileys')

// --- Change description
sock.newsletterUpdateDescription('1231111111111@newsletter', '📣 Fresh updates weekly')

// --- Change photo
sock.newsletterUpdatePicture('1231111111111@newsletter', {
   url: 'path/to/image.jpg'
})

// --- Remove photo
sock.newsletterRemovePicture('1231111111111@newsletter')

// --- React to a message
sock.newsletterReactMessage('1231111111111@newsletter', '100', '💛')

// --- Get admin count
const count = await sock.newsletterAdminCount('1231111111111@newsletter')

// --- Get all subscribed newsletters
const newsletters = await sock.newsletterSubscribed()
console.dir(newsletters, { depth: null })

// --- Fetch newsletter messages
const messages = sock.newsletterFetchMessages('jid', '1231111111111@newsletter', 50, 0, 0)
console.dir(messages, { depth: null })

// --- Delete newsletter
sock.newsletterDelete('1231111111111@newsletter')
```

#### 👥 Group Management

```javascript
// --- Create a new one and add participants using their JIDs
const group = sock.groupCreate('@souzzaaxzy/baileys', ['628123456789@s.whatsapp.net'])
console.dir(group, { depth: null })

// --- Get info
const metadata = await sock.groupMetadata(jid)
console.dir(metadata, { depth: null })

// --- Get group invite code
const inviteCode = await sock.groupInviteCode(jid)
console.dir(inviteCode, { depth: null })


// --- Revoke invite link
sock.groupRevokeInvite(jid)

// --- Accept group invite
sock.groupAcceptInvite(inviteCode)

// --- Leave group
sock.groupLeave(jid)

// --- Add participants
sock.groupParticipantsUpdate(jid, ['628123456789@s.whatsapp.net'], 'add')

// --- Remove participants
sock.groupParticipantsUpdate(jid, ['628123456789@s.whatsapp.net'], 'remove')

// --- Promote to admin
sock.groupParticipantsUpdate(jid, ['628123456789@s.whatsapp.net'], 'promote')

// --- Demote from admin
sock.groupParticipantsUpdate(jid, ['628123456789@s.whatsapp.net'], 'demote')

// --- Accept join requests
sock.groupRequestParticipantsUpdate(jid, ['628123456789@s.whatsapp.net'], 'approve')

// --- Change name
sock.groupUpdateSubject(jid, '📦 @souzzaaxzy/baileys')

// --- Change description
sock.groupUpdateDescription(jid, 'Updated description')

// --- Change photo
sock.updateProfilePicture(jid, {
   url: 'path/to/image.jpg'
})

// --- Remove photo
sock.removeProfilePicture(jid)

// --- Set group as admin only for chatting
sock.groupSettingUpdate(jid, 'announcement')

// --- Set group as open to all for chatting
sock.groupSettingUpdate(jid, 'not_announcement')

// --- Set admin only can edit group info
sock.groupSettingUpdate(jid, 'locked')

// --- Set all participants can edit group info
sock.groupSettingUpdate(jid, 'unlocked')

// --- Set admin only can add participants
sock.groupMemberAddMode(jid, 'admin_add')

// --- Set all participants can add participants
sock.groupMemberAddMode(jid, 'all_member_add')

// --- Enable or disable temporary messages with seconds format
sock.groupToggleEphemeral(jid, 86400)

// --- Disable temporary messages
sock.groupToggleEphemeral(jid, 0)

// --- Enable or disable membership approval mode
sock.groupJoinApprovalMode(jid, 'on')
sock.groupJoinApprovalMode(jid, 'off')

// --- Get all groups metadata
const groups = await sock.groupFetchAllParticipating()
console.dir(groups, { depth: null })

// --- Get pending join requests
const requests = await sock.groupRequestParticipantsList(jid)
console.dir(requests, { depth: null })

// --- Get group info from link
const group = await sock.groupGetInviteInfo('ABC123456789')
console.log('👥 Got group info from invite code', ':', group)

// --- Update bot member label
sock.updateMemberLabel(jid, '@souzzaaxzy/baileys')
```

#### 👥 Community Management

```javascript
// --- Create a new one and add description
const community = await sock.communityCreate('@souzzaaxzy/baileys', '📣 Fresh updates weekly')
console.dir(community, { depth: null })

// --- Create a subgroup for community and add participants using their JIDs
const group = await sock.communityCreateGroup('📢 Announcements', ['628123456789@s.whatsapp.net'], communityJid)

// --- Link an existing group
sock.communityLinkGroup(groupJid, communityJid)

// --- Unlink an existing group
sock.communityUnlinkGroup(groupJid, communityJid)

// --- Get info
const metadata = await sock.communityMetadata(jid)
console.dir(metadata, { depth: null })

// --- Get community invite code
const inviteCode = await sock.communityInviteCode(jid)
console.dir(inviteCode, { depth: null })

// --- Revoke invite link
sock.communityRevokeInvite(jid)

// --- Accept community invite
sock.communityAcceptInvite(inviteCode)

// --- Leave community
sock.communityLeave(jid)

// --- Accept join requests
sock.communityRequestParticipantsUpdate(jid, ['628123456789@s.whatsapp.net'], 'approve')

// --- Change name
sock.communityUpdateSubject(jid, '📦 @souzzaaxzy/baileys')

// --- Change description
sock.communityUpdateDescription(jid, 'Updated description')

// --- Set community as admin only for chatting
sock.communitySettingUpdate(jid, 'announcement')

// --- Set community as open to all for chatting
sock.communitySettingUpdate(jid, 'not_announcement')

// --- Set admin only can edit community info
sock.communitySettingUpdate(jid, 'locked')

// --- Set all participants can edit community info
sock.communitySettingUpdate(jid, 'unlocked')

// --- Set admin only can add participants
sock.communityMemberAddMode(jid, 'admin_add')

// --- Set all participants can add participants
sock.communityMemberAddMode(jid, 'all_member_add')

// --- Enable or disable temporary messages with seconds format
sock.communityToggleEphemeral(jid, 86400)

// --- Disable temporary messages
sock.communityToggleEphemeral(jid, 0)

// --- Enable or disable membership approval mode
sock.communityJoinApprovalMode(jid, 'on')
sock.communityJoinApprovalMode(jid, 'off')

// --- Get all communities metadata
const communities = await sock.communityFetchAllParticipating()
console.dir(communities, { depth: null })

// --- Get all community linked groups
const linked = await sock.communityFetchLinkedGroups(jid)
console.dir(linked, { depth: null })

// --- Get pending join requests
const requests = await sock.communityRequestParticipantsList(jid)
console.dir(requests, { depth: null })

// --- Get community info from link
const community = await sock.communityGetInviteInfo('ABC123456789')
console.log('👥 Got community info from invite code', ':', community)
```

#### 👤 Profile Management

```javascript
// --- Get user profile picture
const url = await sock.profilePictureUrl(jid, 'image')
console.log('🖼️ Got user profile url', url)

// --- Update profile picture
sock.updateProfilePicture(jid, buffer)
sock.updateProfilePicture(jid, { url })

// --- Remove profile picture
sock.removeProfilePicture(jid)

// --- Update profile name
sock.updateProfileName('My Name')

// --- Update profile status
sock.updateProfileStatus('Available')

// --- Presence
sock.sendPresenceUpdate('available', jid)
sock.presenceSubscribe(jid)

// --- Read receipts
sock.readMessages([message.key])
sock.sendReceipt(jid, participant, [messageId], 'read')

// --- Block user
sock.updateBlockStatus(jid, 'block')

// --- Unblock user
sock.updateBlockStatus(jid, 'unblock')

// --- Fetch blocklist
const blocked = await sock.fetchBlocklist()
console.dir(blocked, { depth: null })

// --- Modify chats
sock.chatModify({
   archive: true,
   lastMessageOrig: message,
   lastMessage: message
}, jid)

// --- Star messages
sock.star(jid, [{ id: messageId, fromMe: true }], true)

// --- Contact
sock.addOrEditContact(jid, { displayName: 'Starseed' })
sock.removeContact(jid)

// --- Label
sock.addChatLabel(jid, labelId)
sock.removeChatLabel(jid, labelId)
sock.addMessageLabel(jid, messageId, labelId)

// --- App state sync
sock.resyncAppState(['regular', 'critical_block'], true)

// --- Get business profile
const profile = await sock.getBusinessProfile(jid)
console.dir(profile, { depth: null })

// Same profile read through the business socket, parsed by the shared
// BinaryNode parser (returns every `website`/`category`, plus the cover photo id):
const profileV2 = await sock.getBusinessProfileV2(jid)
console.dir(profileV2, { depth: null })

// --- Update business profile (partial update: only the fields you pass change)
await sock.updateBusinessProfile({
   address: 'Rua 1, 100',
   email: 'contact@example.com',
   description: 'We sell cool things',
   websites: ['https://example.com', 'https://blog.example.com'],
   hours: {
      timezone: 'America/Sao_Paulo',
      days: [
         { day: 'mon', mode: 'specific_hours', openTimeInMinutes: 480, closeTimeInMinutes: 1080 },
         { day: 'sun', mode: 'closed' }
      ]
   }
})

// --- Cover photo of the profile
const coverId = await sock.updateCoverPhoto(bufferImage)
await sock.removeCoverPhoto(coverId)
```

#### 🛒 Business Management

```javascript
// --- Create a new product
const product = await sock.productCreate({
   name: '🧩 Starseed (Premium)',
   description: 'Get a full version of Starseed!',
   price: 100000,
   currency: 'IDR',
   originCountryCode: 'ID',
   images: [
      bufferImage,
      {
         url: './path/to/image.jpg'
      }
   ]
})
console.dir(product, { depth: null })

// --- Update product
await sock.productUpdate(productId, {
   name: '🧩 Starseed (Premium)',
   description: 'Get a full version of Starseed with more features!',
   price: 75000,
   currency: 'IDR',
   images: [
      {
         url: './path/to/image.jpg'
      }
   ]
})

// --- Delete product
sock.productDelete([productId])

// --- Get catalog info
const { products, nextPageCursor } = await sock.getCatalog({
  jid: '628123456789@s.whatsapp.net',
  limit: 10
})

// --- Get collections
const collections = await sock.getCollections('628123456789@s.whatsapp.net', 10)
console.dir(collections, { depth: null })

// --- Get order info
const order = await sock.getOrderDetails(orderId, tokenBase64)
console.dir(order, { depth: null })

// --- Update business profile
await sock.updateBusinessProfile({
   address: 'Jakarta, Indonesia',
   description: '🛒 Official Starseed Store',
   websites: ['https://github.com/Souzzaaxzy/baileys'],
   email: 'more-more@gmail.com',
   hours: {
      timezone: 'Asia/Jakarta',
      days: [{ day: 'mon', mode: 'open_24h' }]
   }
})

// --- Update cover
sock.updateCoverPhoto({
   url: './path/to/image.jpg'
})

// --- Remove cover
sock.removeCoverPhoto(coverId)

// --- Update quick replies
sock.addOrEditQuickReply({
  shortcut: 'hello',
  message: 'Hello from business account',
})

// --- Remove quick reply
sock.removeQuickReply(timestamp)
```

#### 🔐 Privacy Management

```javascript
// --- Update last seen privacy
sock.updateLastSeenPrivacy('all')
sock.updateLastSeenPrivacy('contacts')
sock.updateLastSeenPrivacy('contact_blacklist')
sock.updateLastSeenPrivacy('nobody')

// --- Update online privacy
sock.updateOnlinePrivacy('all')
sock.updateOnlinePrivacy('match_last_seen')

// --- Update profile picture privacy
sock.updateProfilePicturePrivacy('contacts')

// --- Update status privacy
sock.updateStatusPrivacy('contacts')

// --- Update read receipts privacy
sock.updateReadReceiptsPrivacy('all')
sock.updateReadReceiptsPrivacy('none')

// --- Update groups add privacy
sock.updateGroupsAddPrivacy('all')
sock.updateGroupsAddPrivacy('contacts')

// --- Update messages privacy
sock.updateMessagesPrivacy('all')
sock.updateMessagesPrivacy('contacts')
sock.updateMessagesPrivacy('nobody')

// --- Update call privacy
sock.updateCallPrivacy('everyone')

// --- Update default disappearing mode
sock.updateDefaultDisappearingMode(86400)

// --- Update link previews privacy
sock.updateDisableLinkPreviewsPrivacy(true)
```

#### 📡 Events

```javascript
sock.ev.on('connection.update', (update) => {})
sock.ev.on('creds.update', (update) => {})
sock.ev.on('messaging-history.set', (update) => {})
sock.ev.on('messaging-history.status', (update) => {})
sock.ev.on('chats.upsert', (update) => {})
sock.ev.on('chats.update', (update) => {})
sock.ev.on('chats.delete', (update) => {})
sock.ev.on('chats.lock', (update) => {})
sock.ev.on('lid-mapping.update', (update) => {})
sock.ev.on('presence.update', (update) => {})
sock.ev.on('contacts.upsert', (update) => {})
sock.ev.on('contacts.update', (update) => {})
sock.ev.on('messages.delete', (update) => {})
sock.ev.on('messages.update', (update) => {})
sock.ev.on('messages.media-update', (update) => {})
sock.ev.on('messages.upsert', (update) => {})
sock.ev.on('messages.reaction', (update) => {})
sock.ev.on('message-receipt.update', (update) => {})
sock.ev.on('groups.upsert', (update) => {})
sock.ev.on('groups.update', (update) => {})
sock.ev.on('group-participants.update', (update) => {})
sock.ev.on('group.join-request', (update) => {})
sock.ev.on('group.member-tag.update', (update) => {})
sock.ev.on('blocklist.set', (update) => {})
sock.ev.on('blocklist.update', (update) => {})
sock.ev.on('call', (update) => {})
sock.ev.on('labels.edit', (update) => {})
sock.ev.on('labels.association', (update) => {})
sock.ev.on('newsletter.reaction', (update) => {})
sock.ev.on('newsletter.view', (update) => {})
sock.ev.on('newsletter-participants.update', (update) => {})
sock.ev.on('newsletter-settings.update', (update) => {})
sock.ev.on('settings.update', (update) => {})
```

#### 👥 Join request — quem aprovou/recusou

`group.join-request` traz o pedido de entrada **e** quem o resolveu. São três
campos que se confundem:

| campo | quem é |
|---|---|
| `participant` / `participantPn` | quem **pediu** para entrar (o afetado) |
| `author` / `authorPn` | quem **agiu** — quem aprovou ou recusou |
| `action` | `created` \| `revoked` \| `rejected` |

`revoked` é o **próprio solicitante cancelando** o pedido; `rejected` é um
**admin recusando**. A distinção sai de comparar o ator com o afetado — quando
são a mesma pessoa, foi cancelamento.

> [!IMPORTANT]
> A `action` é **sempre** preenchida. O stub do WhatsApp só a define no caminho
> de `revoked_membership_requests`; nos demais ela vinha `undefined`, e um
> consumidor não tinha como separar "pedido novo" de "pedido resolvido" —
> tratando uma recusa como se fosse um pedido novo. A derivação usa apenas o
> que a stanza já carrega (ator × afetado), sem inventar nada, e mantém as
> actions canônicas quando o stub as traz.

```javascript
sock.ev.on('group.join-request', ({ id, participant, participantPn, author, authorPn, action, method }) => {
    if (action === 'created') return // pedido novo
    if (action === 'revoked') return // o solicitante cancelou
    if (action === 'rejected') {
        // um admin recusou: `author` é quem recusou
    }
})
```

### 📞 Voice & Video Calls (VoIP media)

Two layers live in this package, and it is worth knowing which is which:

| Layer | Where | What it does |
|---|---|---|
| **Signaling** | `offerCall` / `offerGroupCall` / `terminateCall` / `rejectCall` | Builds the `<call>` stanzas. The call *exists* — it rings, can be answered, can be ended. **Carries no sound.** |
| **Media** | `Voip` (this section) | The WASM VoIP engine, the relay transport and the audio pipeline. **This is what puts audio on the wire.** |

Signaling alone is not a working call: media is RTP/SRTP over UDP to a relay, with keys negotiated separately and Opus encoding driven by WhatsApp Web's own engine. The media stack is ported from [`lizzy-call`](https://github.com/Souzzaaxzy/lizzy-call) (itself a fork of [baileys-caller](https://github.com/SheIITear/baileys-caller) by ShellTear, MIT), with group support and a fix for the Linux worker hang (see below).

> [!IMPORTANT]
> **Calls need a desktop/UWP identity.** WhatsApp only enables the media stack for clients that advertise themselves as desktop/UWP — a plain Chrome identity gets signaling but no voice. This fork already does the right thing in `Utils/validate-connection.js` (`getPlatformType` maps `UWP`/`DESKTOP`), so set the browser preset accordingly:
>
> ```js
> const sock = makeWASocket({
>   auth: state,
>   browser: Browsers.windows('UWP'),
>   markOnlineOnConnect: false,
> })
> ```

#### 🔌 Socket session (group calls)

Rides the socket you already have — no extra device, no second login:

```js
import { Voip } from '@souzzaaxzy/baileys'

const voip = Voip.makeVoipSession(sock, { log: console.log })

// pre-flight: refuse a call that would be OOM-killed instead of dying silently
console.log(voip.checkMemory()) // { ok, livreMb, minFreeMb }

// join the group call as a media participant
await voip.entrarNaCall({
  grupo: '123456789-123456@g.us',
  participantes: ['5511...@s.whatsapp.net'],
})

// play a file into the call (ffmpeg → 16 kHz mono PCM → engine uplink)
await voip.tocarAudio('123456789-123456@g.us', './song.mp3')
await voip.pararAudio('123456789-123456@g.us')

// leave and release the media stack
await voip.sairDaCall('123456789-123456@g.us')
```

The facade is **lazy**: nothing is allocated until the first call, so a bot that never calls pays none of the memory cost.

Lower-level pieces are exported too, if you need them directly:

```js
import { Voip } from '@souzzaaxzy/baileys'

new Voip.GroupCallMedia({ log })
new Voip.WasmEngine({ resourcesPath: Voip.VOIP_PACKAGE_ROOT, callbacks: { /* ... */ } })
new Voip.SignalingBridge({ sock })
new Voip.RelayRtcTransport({ /* ... */ })
```

#### 📱 Standalone client (1:1 calls)

For a call fully decoupled from the bot — its own auth dir, its own QR:

```js
import { Voip } from '@souzzaaxzy/baileys'

const client = new Voip.VoipClient({ authDir: './call-auth' })
await client.connect()

const call = await client.call('5511999999999', {
  audioSource: './hello.mp3', // or "silence"
  durationMs: 120_000,
})

call.on('connected', () => console.log('media flowing'))
call.on('ended', (reason) => console.log('ended:', reason))
```

`VoipClient` extends `EventEmitter` and emits `ringing`, `connected`, `audio` (16 kHz mono PCM frames), `ended` and `error`.

#### 🧠 Memory & workers

The media stack is the heaviest thing in the package. Measured: **~45 MB per pthread worker**, and a single call holds a pool of them — the SDK's original default of 20 workers came to **~900 MB for one call**, which on a small VPS ends in the OOM killer sending `SIGKILL`. That surfaces as *"the bot restarted by itself"*, with no log, because `SIGKILL` cannot be caught.

| Env var | Default | Purpose |
|---|---|---|
| `CALL_PTHREAD_POOL_SIZE` | `6` | Prewarmed WASM workers. Lower = less RAM, less headroom. |
| `CALL_WORKER_LOAD_TIMEOUT_MS` | `20000` | How long to wait for each worker to report `loaded` before discarding it. |

```js
Voip.checkVoipMemory() // { ok, livreMb, minFreeMb } — refuse before you OOM
Voip.VOIP_MIN_FREE_MB  // 700
```

#### 🐢 "Stuck on connecting"

The classic failure — *the call goes up, sits on "connecting" for ~50 s, then the process dies* — has a specific cause, measured on Linux in [baileys-caller issue #1](https://github.com/SheIITear/baileys-caller/issues/1): **19 of 20 prewarmed workers report `loaded`, one never does.** A bare `Promise.all` over those promises then never resolves, so the engine never finishes initializing and the media never becomes ready.

This port does not use a bare `Promise.all`. Each worker gets its own timeout; the ones that load join the pool, the ones that hang are discarded (and terminated, so they do not hold memory) and the reason is logged. `initialize()` always settles — degraded is better than hung.

Regression tests for exactly this:

```bash
node tests/voip-engine-boot.test.js     # initialize() resolves, with real memory numbers
node tests/voip-worker-timeout.test.js  # every worker times out → still settles, and reports it
node tests/voip-session.test.js         # lazy facade + memory pre-flight
```

#### 🔊 Keeping the call up (and the music playing)

A call that goes quiet does not stay up. Two behaviours matter once a file ends:

- **Keep-alive (default on).** When the source plays out, the feeder keeps
  emitting **silence** instead of stopping. A dead RTP stream is what makes the
  relay treat the leg as idle and drop it — the *"the call does not hold"*
  symptom. This mirrors what Meta's own integration examples do (inject a silent
  stream so the media path stays established).
- **Loop (opt-in).** `{ loop: true }` replays the file, so music keeps playing
  instead of stopping after one pass.

```js
await voip.tocarAudio(grupo, './song.mp3')                  // plays once, then silence
await voip.tocarAudio(grupo, './song.mp3', { loop: true })  // repeats until you stop it
await voip.tocarAudio(grupo, './song.mp3', { keepAlive: false }) // stop the stream when done
await voip.pararAudio(grupo)                                // stop audio, keep the call
```

> [!NOTE]
> `stop()` is final — a looping feeder does not resurrect itself. This was a real
> bug found by the test (`stop()` still flushed a few buffered chunks after
> being called), fixed and locked in `tests/voip-audio-continuity.test.js`.

```bash
node tests/voip-audio-continuity.test.js  # keep-alive, loop, and stop()
node tests/voip-signaling-dispose.test.js # teardown does not leak socket hooks
node tests/voip-voice-identity.test.js    # the UWP + 5-part build-id identity
```

#### 🎭 The right identity (voice-capable)

The package default (`Browsers.macOS('Chrome')`, 3-part version) is **not**
voice-capable. Use the preset:

```js
import { Browsers } from '@souzzaaxzy/baileys'

const { browser, version } = Browsers.voiceCapable('UWP')
const sock = makeWASocket({ auth: state, browser, version, markOnlineOnConnect: false })
```

And assert it, so the mistake is never silent:

```js
import { isVoiceCapableConfig } from '@souzzaaxzy/baileys'

const check = isVoiceCapableConfig(config)
// { ok: false, reason: 'browser "Chrome" nao e UWP/DESKTOP — o WhatsApp nao habilita a midia da call (voz fica muda)' }
```

`VOICE_CAPABLE_VERSION` (the pinned 5-part build id) is exported too, if you
need to reference it directly.

### 🚀 Try the Bot

A fast, lightweight, and modular WhatsApp bot built with [@souzzaaxzy/baileys](https://github.com/Souzzaaxzy/baileys).
Perfect for managing groups, moderating chats, and adding fun with quiz games and handy tools.

👉🏻 [@itsliaaa/starseed](https://github.com/itsliaaa/starseed#readme)

A lightweight yet powerful Baileys wrapper designed to simplify development while extending support for additional message types and WhatsApp features.

👉🏻 [@itsliaaa/starcore](https://www.npmjs.com/package/@itsliaaa/starcore)

### 📦 Fork Base

This fork is based on [Baileys (GitHub)](https://github.com/WhiskeySockets/Baileys)

### 📣 Credits

This fork uses Protocol Buffer definitions maintained by [WPP Connect](https://github.com/wppconnect-team) via [`wa-proto`](https://github.com/wppconnect-team/wa-proto)

Full credit is attributed to the original maintainers and contributors of Baileys:
- [purpshell](https://github.com/purpshell)
- [jlucaso1](https://github.com/jlucaso1)
- [adiwajshing](https://github.com/adiwajshing)

<!-- Please do not replace my name with yours. It's disrespectful. -->

This fork includes additional enhancements and modifications by [Lia Wynn](https://github.com/itsliaaa)

Special thanks to [itsreimau](https://github.com/itsreimau) for the fix to the `updateBlockStatus` implementation.

> [!CAUTION]
> ⚠️ **Modification, removal, or misrepresentation of these credits is strictly prohibited. Any redistribution or fork must preserve this section in its original form without exception.**